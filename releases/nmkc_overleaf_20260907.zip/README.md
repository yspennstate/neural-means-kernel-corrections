# Neural means and kernel corrections for operator learning

This project contains the main article, its supplement, bibliography, figures,
and compiled PDFs.

## Overleaf

1. Upload the ZIP as a new project.
2. Select **pdfLaTeX** and set **main.tex** as the main document.
3. Recompile. The build configuration also compiles **supplement.tex** and
   resolves references between the two documents.

To display the supplement in Overleaf, select **supplement.tex** as the main
document. Keep the compiled files named **main.pdf** and **supplement.pdf**
together when downloading them so links between the documents continue to work.

## Local compilation

With a standard TeX Live installation containing latexmk, run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The project uses the included preprint style and requires no shell-escape setting.
The build helper writes temporary files under `nmkc-build/`.

## Figures and numerical material

The numerical inputs and Python script for the three regenerated figures are in
`figure_sources/`. All figures required to compile the documents are included;
Python is not required for compilation.

The package contains the manuscript sources, compiled PDFs, figures, and
numerical tables. Data and code availability is described in the main article.

The experimental code is available at
https://github.com/yspennstate/neural-means-kernel-corrections.

`EXPERIMENTS.md` maps the experiments to their implementation and record paths
in a pinned version of the public repository.
