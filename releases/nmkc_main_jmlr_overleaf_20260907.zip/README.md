# Neural Means and Kernel Corrections for Operator Learning

This project builds the main article only.

Upload the ZIP as a new Overleaf project, choose pdfLaTeX, and set main.tex as the main document. For local compilation, run:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The official JMLR style file is included without modification. Its preprint option leaves editor-assigned publication information unset for initial submission. All figures and bibliography entries required by the main article are included.

Online Appendix 1 is a separate document. The imported S-numbered references match the supplied supplement. Before submitting the two documents together, update the supplement's references back to the main article to use this version's consecutive theorem numbering.
